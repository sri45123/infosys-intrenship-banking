const BASE_URL = "http://localhost:8080";
const APP_PIN = "1234";
let authToken = localStorage.getItem("nb_auth_token") || "";
let authName = localStorage.getItem("nb_auth_name") || "";

function showSection(id) {
    document.querySelectorAll(".section").forEach((sec) => {
        sec.style.display = "none";
    });
    document.getElementById(id).style.display = "block";
}

function isValidAmount(value) {
    return Number.isFinite(value) && value > 0;
}

function notify(message, type) {
    const banner = document.getElementById("notification");
    banner.className = "notification " + (type || "success");
    banner.textContent = message;
    banner.classList.remove("hidden");
}

function updateAuthStatus() {
    const status = document.getElementById("auth-status");
    if (authToken) {
        status.textContent = "Logged in as " + (authName || "User");
        status.classList.add("is-auth");
    } else {
        status.textContent = "Not logged in";
        status.classList.remove("is-auth");
    }
}

function requireAuth() {
    if (authToken) {
        return true;
    }
    notify("Please login first to continue.", "error");
    showSection("auth");
    return false;
}

function setLoading(active) {
    const indicator = document.getElementById("global-loading");
    indicator.classList.toggle("hidden", !active);
    document.querySelectorAll("button").forEach((btn) => {
        btn.disabled = active;
    });
}

function setResult(id, message, isError) {
    const node = document.getElementById(id);
    node.style.color = isError ? "#9f2020" : "#0f6d3a";
    node.textContent = message;
}

async function apiRequest(path, method, payload) {
    setLoading(true);
    try {
        const res = await fetch(BASE_URL + path, {
            method,
            headers: {
                "Content-Type": "application/json",
                "Authorization": authToken ? "Bearer " + authToken : ""
            },
            body: payload ? JSON.stringify(payload) : undefined
        });

        const text = await res.text();
        if (!res.ok) {
            try {
                const data = JSON.parse(text);
                throw new Error(data.message || "Request failed");
            } catch (err) {
                if (err instanceof SyntaxError) {
                    throw new Error(text || "Request failed");
                }
                throw err;
            }
        }

        try {
            return JSON.parse(text);
        } catch (_err) {
            return text;
        }
    } finally {
        setLoading(false);
    }
}

async function registerUser() {
    const name = document.getElementById("r-name").value.trim();
    const email = document.getElementById("r-email").value.trim();
    const password = document.getElementById("r-password").value;

    if (!name || !email || !password) {
        setResult("register-result", "Name, email and password are required.", true);
        notify("Registration failed: missing details.", "error");
        return;
    }

    try {
        const data = await apiRequest("/auth/register", "POST", { name, email, password });
        setResult("register-result", data.message || "Registration successful.", false);
        notify("Registration successful. Please login.", "success");
    } catch (err) {
        setResult("register-result", err.message, true);
        notify("Registration failed: " + err.message, "error");
    }
}

async function loginUser() {
    const email = document.getElementById("l-email").value.trim();
    const password = document.getElementById("l-password").value;

    if (!email || !password) {
        setResult("login-result", "Email and password are required.", true);
        notify("Login failed: missing credentials.", "error");
        return;
    }

    try {
        const data = await apiRequest("/auth/login", "POST", { email, password });
        authToken = data.token || "";
        authName = data.name || "";
        localStorage.setItem("nb_auth_token", authToken);
        localStorage.setItem("nb_auth_name", authName);
        updateAuthStatus();
        setResult("login-result", data.message || "Login successful.", false);
        notify("Login successful.", "success");
        showSection("create");
    } catch (err) {
        setResult("login-result", err.message, true);
        notify("Login failed: " + err.message, "error");
    }
}

function logoutUser() {
    authToken = "";
    authName = "";
    localStorage.removeItem("nb_auth_token");
    localStorage.removeItem("nb_auth_name");
    updateAuthStatus();
    notify("Logged out successfully.", "success");
    showSection("auth");
}

async function createAccount() {
    if (!requireAuth()) {
        return;
    }

    const name = document.getElementById("c-name").value.trim();
    const email = document.getElementById("c-email").value.trim();
    const balance = parseFloat(document.getElementById("c-balance").value);

    if (!name || !email) {
        setResult("create-result", "Name and email are required.", true);
        notify("Create account failed: missing details.", "error");
        return;
    }

    if (!isValidAmount(balance) && balance !== 0) {
        setResult("create-result", "Enter a valid opening balance.", true);
        notify("Create account failed: invalid opening balance.", "error");
        return;
    }

    try {
        const result = await apiRequest("/accounts/create", "POST", { name, email, balance: Number.isFinite(balance) ? balance : 0 });
        const msg = "Account created successfully. Number: " + result.accountNumber;
        setResult("create-result", msg, false);
        notify(msg, "success");
    } catch (err) {
        setResult("create-result", err.message, true);
        notify("Create account failed: " + err.message, "error");
    }
}

async function deposit() {
    if (!requireAuth()) {
        return;
    }

    const accNo = document.getElementById("d-acc").value.trim();
    const amount = parseFloat(document.getElementById("d-amount").value);

    if (!accNo || !isValidAmount(amount)) {
        setResult("deposit-result", "Provide valid account number and amount.", true);
        notify("Deposit failed due to invalid input.", "error");
        return;
    }

    try {
        const msg = await apiRequest("/transactions/deposit", "POST", { accNo, amount });
        setResult("deposit-result", msg, false);
        notify("Deposit completed successfully.", "success");
    } catch (err) {
        setResult("deposit-result", err.message, true);
        notify("Deposit failed: " + err.message, "error");
    }
}

async function withdraw() {
    if (!requireAuth()) {
        return;
    }

    const accNo = document.getElementById("w-acc").value.trim();
    const amount = parseFloat(document.getElementById("w-amount").value);

    if (!accNo || !isValidAmount(amount)) {
        setResult("withdraw-result", "Provide valid account number and amount.", true);
        notify("Withdraw failed due to invalid input.", "error");
        return;
    }

    try {
        const msg = await apiRequest("/transactions/withdraw", "POST", { accNo, amount });
        setResult("withdraw-result", msg, false);
        notify("Withdraw completed successfully.", "success");
    } catch (err) {
        setResult("withdraw-result", err.message, true);
        notify("Withdraw failed: " + err.message, "error");
    }
}

async function transfer() {
    if (!requireAuth()) {
        return;
    }

    const fromAcc = document.getElementById("t-from").value.trim();
    const toAcc = document.getElementById("t-to").value.trim();
    const amount = parseFloat(document.getElementById("t-amount").value);

    if (!fromAcc || !toAcc || !isValidAmount(amount)) {
        setResult("transfer-result", "Enter valid sender, receiver, and amount.", true);
        notify("Transfer failed due to invalid input.", "error");
        return;
    }

    if (fromAcc === toAcc) {
        setResult("transfer-result", "Sender and receiver cannot be same.", true);
        notify("Transfer failed: account numbers cannot match.", "error");
        return;
    }

    try {
        const msg = await apiRequest("/transactions/transfer", "POST", { fromAcc, toAcc, amount });
        setResult("transfer-result", msg, false);
        notify("Transfer completed successfully.", "success");
    } catch (err) {
        setResult("transfer-result", err.message, true);
        notify("Transfer failed: " + err.message, "error");
    }
}

async function viewAccount() {
    if (!requireAuth()) {
        return;
    }

    const acc = document.getElementById("v-acc").value.trim();
    if (!acc) {
        notify("Please enter account number to view balance.", "error");
        return;
    }

    try {
        const data = await apiRequest("/accounts/" + encodeURIComponent(acc), "GET");
        const card = document.getElementById("view-result");
        card.classList.remove("hidden");
        card.innerHTML = [
            "<div><strong>Account Holder:</strong> " + data.holderName + "</div>",
            "<div><strong>Account Number:</strong> " + data.accountNumber + "</div>",
            "<div class='amount'>Current Balance: Rs " + data.openingBalance + "</div>"
        ].join("");
        notify("Balance loaded successfully.", "success");
    } catch (err) {
        document.getElementById("view-result").classList.add("hidden");
        notify("View balance failed: " + err.message, "error");
    }
}

async function loadHistory() {
    if (!requireAuth()) {
        return;
    }

    const acc = document.getElementById("h-acc").value.trim();
    const target = document.getElementById("history-result");
    target.innerHTML = "";

    try {
        const path = acc ? "/transactions/history/" + encodeURIComponent(acc) : "/transactions/history";
        const data = await apiRequest(path, "GET");
        if (!Array.isArray(data) || data.length === 0) {
            target.innerHTML = "<li>No transactions found.</li>";
            notify("No history entries found.", "error");
            return;
        }

        target.innerHTML = data.map((line) => "<li>" + line + "</li>").join("");
        notify("Transaction history loaded.", "success");
    } catch (err) {
        target.innerHTML = "<li>Failed to load history.</li>";
        notify("History load failed: " + err.message, "error");
    }
}

async function listAccounts() {
    if (!requireAuth()) {
        return;
    }

    try {
        const data = await apiRequest("/accounts/all", "GET");
        document.getElementById("list-result").innerText = JSON.stringify(data, null, 2);
        notify("Accounts loaded.", "success");
    } catch (err) {
        document.getElementById("list-result").innerText = "[]";
        notify("Failed to load accounts: " + err.message, "error");
    }
}

function openLock() {
    document.getElementById("lock-result").textContent = "";
    document.getElementById("lock-pin").value = "";
    document.getElementById("lock-overlay").classList.remove("hidden");
}

function closeLock() {
    document.getElementById("lock-overlay").classList.add("hidden");
}

function unlockApp() {
    const pin = document.getElementById("lock-pin").value.trim();
    if (pin === APP_PIN) {
        closeLock();
        notify("Unlocked successfully.", "success");
        return;
    }

    document.getElementById("lock-result").style.color = "#9f2020";
    document.getElementById("lock-result").textContent = "Invalid PIN";
}

updateAuthStatus();
showSection(authToken ? "create" : "auth");














